# Insurance Sales Performance Analysis

**Status:** Starter project / in progress

## Purpose
Practice analyzing synthetic insurance sales data to understand policy sales, premium collection, product performance, regional performance, and sales channels.

## Files
- `insurance_sales_sample.csv` — synthetic sample data created for practice; not real customer or company data.
- `analysis_queries.sql` — SQL queries for basic analysis.
- `README.md` — project overview and suggested next steps.

## Tools
- SQL
- Excel / Power Query (next step)
- Power BI (dashboard next step)

## Questions to answer
1. How many policies were sold?
2. Which region collected the highest premium?
3. Which product type performed best?
4. How did performance change month by month?
5. Which sales channel contributed the most premium?
6. Which records did not result in a policy sale?

## Next steps
1. Import the CSV into your SQL workbench.
2. Run queries in `analysis_queries.sql` and check the results.
3. Clean and summarize the data in Excel or Power Query.
4. Build a Power BI dashboard with KPI cards and charts.
5. Add your own findings after completing the analysis.

**Important:** This is a learning starter project using synthetic data. Do not describe it as completed until you have performed the analysis and built the dashboard. Never upload real customer or employer-confidential data.
