-- Insurance Sales Performance Analysis - starter practice queries
-- Import the CSV into a SQL table named insurance_sales first.

SELECT * FROM insurance_sales;

-- 1. Total policies sold
SELECT SUM(policy_sold) AS total_policies_sold
FROM insurance_sales;

-- 2. Total premium collected
SELECT SUM(premium_collected) AS total_premium_collected
FROM insurance_sales;

-- 3. Performance by region
SELECT region,
       SUM(policy_sold) AS policies_sold,
       SUM(premium_collected) AS premium_collected
FROM insurance_sales
GROUP BY region
ORDER BY premium_collected DESC;

-- 4. Performance by product
SELECT product_type,
       SUM(policy_sold) AS policies_sold,
       SUM(premium_collected) AS premium_collected
FROM insurance_sales
GROUP BY product_type
ORDER BY premium_collected DESC;

-- 5. Monthly performance (works with YYYY-MM-DD date text)
SELECT SUBSTRING(sale_date, 1, 7) AS sale_month,
       SUM(policy_sold) AS policies_sold,
       SUM(premium_collected) AS premium_collected
FROM insurance_sales
GROUP BY SUBSTRING(sale_date, 1, 7)
ORDER BY sale_month;

-- 6. Performance by sales channel
SELECT sales_channel,
       SUM(policy_sold) AS policies_sold,
       SUM(premium_collected) AS premium_collected
FROM insurance_sales
GROUP BY sales_channel
ORDER BY premium_collected DESC;

-- 7. Records where no policy was sold
SELECT *
FROM insurance_sales
WHERE policy_sold = 0;
